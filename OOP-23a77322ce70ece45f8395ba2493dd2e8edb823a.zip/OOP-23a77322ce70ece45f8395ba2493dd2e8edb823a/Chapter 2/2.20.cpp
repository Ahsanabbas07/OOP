#include <iostream>
using namespace std;

int main ()
{
	
	
	int r,d,a,c;
	const int pi=3.14159;
	cout<<"Enter radius: ";
	cin>>r;
	d=2*r;
	a=pi*r^2;
	c=2*pi*r;
	cout<<"Diameter of Circle= "<<d<<"\n";
	cout<<"Area of Circle= "<<a<<"\n";
	cout<<"Circumference of Circle= "<<c<<"\n";
	
	
	
	
	
	return 0;
	
	
}
