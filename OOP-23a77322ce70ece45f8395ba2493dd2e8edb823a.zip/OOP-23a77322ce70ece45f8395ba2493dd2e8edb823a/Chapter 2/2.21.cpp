#include <iostream>
using namespace std;

int main ()
{
	cout<<"  CCC"<<"\t"<<"  +"<<"\t"<<"  +"<<"\n";
	cout<<" C"<<"\t"<<"  +"<<"\t"<<"  +"<<"\n";
	cout<<"C"<<"\t"<<"+++++"<<"\t"<<"+++++"<<"\n";
	cout<<" C"<<"\t"<<"  +"<<"\t"<<"  +"<<"\n";
	cout<<"  CCC"<<"\t"<<"  +"<<"\t"<<"  +"<<"\n";

	return 0;
	
	
}
