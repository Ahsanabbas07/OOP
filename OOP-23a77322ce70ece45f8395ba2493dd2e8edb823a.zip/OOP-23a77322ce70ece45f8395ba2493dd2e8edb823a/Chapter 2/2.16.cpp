#include <iostream>
using namespace std;

int main ()
{
	int a,b;
	int sum,product,div,subtract;
	cout<<"Enter value of a: ";
	cin>>a;
	cout<<"Enter value of b: ";
	cin>>b;
	sum=a+b;
	product=a*b;
	div=a/b;
	subtract=a-b;
	cout<<"Sum of a and b= "<<sum<<"\n";
	cout<<"Product of a and b= "<<product<<"\n";
	cout<<"Division of a and b= "<<div<<"\n";
	cout<<"Subtraction of a and b= "<<subtract<<"\n";


	return 0;
	
	
}
