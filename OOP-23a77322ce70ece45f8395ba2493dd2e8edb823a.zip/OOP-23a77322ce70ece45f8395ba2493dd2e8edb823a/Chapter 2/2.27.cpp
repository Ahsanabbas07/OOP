#include <iostream>
using namespace std;

int main ()
{
	char a;
	cout<<"Enter Value of a: ";
	cin>>a;
	cout<<"Integar value of "<<a<<" is "<< (int)a;
	
	
	return 0;
	
	
}
