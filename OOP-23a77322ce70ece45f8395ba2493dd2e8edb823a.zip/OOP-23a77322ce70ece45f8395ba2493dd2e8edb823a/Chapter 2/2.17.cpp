#include <iostream>
using namespace std;

int main ()
{
	/* part a...*/
	
	cout<<"Welcome to "<<"C++ programming"<<"\n";
	
	// part b //
	
	cout<<"Welcome "<<"to "<<"C++ "<<"programming"<<"\n";
	
	//part c //
	
	cout<<"Welcome to ""C++ programming";
	
	
	return 0;
	
	
}
