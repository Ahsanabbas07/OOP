#include<iostream>
using namespace std;
int main(){
	cout<<"integer\tPeri\tArea\n";
	for(int a=1;a<=5;a++){
		cout<<a<<"\t"<<a*4<<"\t"<<a*a<<"\n";
	}
}

